<footer class="footer">
      <div class="containerfootter">
        <div class="row">
          <div class="footer-col">
            <h4>Usefull Link</h4>
            <ul>
              <li><a href="https://bauet.ac.bd/">University Website</a></li>
              <li><a href="#">Career Services</a></li>
              <li><a href="#">Events and Reunions</a></li>
              <li><a href="#">Mentorship Programs</a></li>
              <li><a href="#">Bauet Computer Society</a></li>
            </ul>
          </div>
          <div class="footer-col">
            <h4>get help</h4>
            <ul>
              <li><a href="#">FAQ</a></li>
              <li><a href="#">Report Problem</a></li>
              <li><a href="#">Contact us</a></li>
            </ul>
          </div>
          <div class="footer-col">
            <h4>Contact</h4>
            <ul>
              <li><a href="#">info@bauet.ac.bd </a></li>
              <li><a href="#">+8801708503510 </a></li>
              <li><a href="#"> Notice</a></li>
              <li><a href="#">Event</a></li>
            </ul>
          </div>
          <div class="footer-col">
            <h4>follow us</h4>
            <div class="social-links">
              <a href="#"><i class="fab fa-facebook-f"></i></a>
              <a href="#"><i class="fab fa-twitter"></i></a>
              <a href="#"><i class="fab fa-instagram"></i></a>
              <a href="#"><i class="fab fa-linkedin-in"></i></a>
            </div>
          </div>
        </div>
      </div>
    </footer>