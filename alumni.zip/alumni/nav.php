<nav>
      <input type="checkbox" id="check" />
      <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
      </label>
      <label class="logo">BAUET Alumni</label>
      <ul>
        <li><a class="" href="index.php">Home</a></li>
        <li><a href="allevent.php">Program & Events</a></li>
        <li><a href="#">ALUMNI STORY </a></li>
        <li><a href="profilecard.php">All Alumni</a></li>
        <li><a href="#">Contact Us</a></li>
      </ul>
    </nav>